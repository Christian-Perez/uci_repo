 #!/bin/bash
#TODO: input is a valid 4 digit month-date combo? do else error

target_date=$1 #0101
target_time=$2 #12:00:00
target_am_pm=$3 #AM

#NOTE: can also accept target time && am/pm in same var by surrounding var in '""'

#TODO: confirm is actually a date

#TODO: confirm is valid time 12:00:00

#TODO: confirm is "AM, am, PM, pm"

dealer_schedule_file_root=/home/sysadmin/Projects/lucky_duck_investigations/roulette_loss_investigation/dealer_analysis
target_dealer_schedule=$dealer_schedule_file_root"/"$target_date"_Dealer_schedule"

grep $target_time" "$target_am_pm $target_dealer_schedule | awk -F " " '{print $1" "$2" "$5" "$6}'
