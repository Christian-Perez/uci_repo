#!/bin/bash
#TODO: input is a valid 4 digit month-date combo? do else error

date=$1

loss_times_file_root=/home/sysadmin/Projects/lucky_duck_investigations/roulette_loss_investigation/dealer_analysis/loss_times
loss_times_file=$loss_times_file_root"/"$date"_loss_times"

dealer_schedule_file_root=/home/sysadmin/Projects/lucky_duck_investigations/roulette_loss_investigation/dealer_analysis
dealer_schedule_file=$dealer_schedule_file_root"/"$date"_Dealer_schedule"

#echo $dealer_schedule_file

#occurrence_count=0

cat $loss_times_file | while read loss_time
do
# echo "loss_time: $loss_time"
 grep "$loss_time" $dealer_schedule_file | awk -F " " '{print $1" "$2" "$5" "$6}' >> dealers_working_during_losses
done
